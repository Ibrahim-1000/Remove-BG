package com.liftapp.cutout.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.unit.dp
import com.liftapp.cutout.AppViewModel
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private fun blobPath(cx: Float, cy: Float, r: Float, t: Float): Path {
    val n = 9
    val pts = ArrayList<Offset>()
    for (i in 0 until n) {
        val a = (i / n.toFloat()) * 2f * PI.toFloat()
        val k = 1f + 0.17f * sin(3f * a + t) + 0.09f * sin(5f * a - 2f * t + 1f)
        pts.add(Offset(cx + cos(a) * r * 1.2f * k, cy + sin(a) * r * k))
    }
    val p = Path()
    p.moveTo(pts[0].x, pts[0].y)
    for (i in 0 until n) {
        val p0 = pts[(i - 1 + n) % n]
        val p1 = pts[i]
        val p2 = pts[(i + 1) % n]
        val p3 = pts[(i + 2) % n]
        p.cubicTo(
            p1.x + (p2.x - p0.x) / 6f, p1.y + (p2.y - p0.y) / 6f,
            p2.x - (p3.x - p1.x) / 6f, p2.y - (p3.y - p1.y) / 6f,
            p2.x, p2.y
        )
    }
    p.close()
    return p
}

@Composable
fun HomeScreen(vm: AppViewModel, onSingle: () -> Unit, onBulk: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "home")
    val morph = inf.animateFloat(
        0f, (2.0 * PI).toFloat(),
        infiniteRepeatable(tween(12000, easing = LinearEasing)),
        label = "morph"
    )
    val slide = inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2400, easing = LinearEasing)),
        label = "slide"
    )
    val pulse = inf.animateFloat(
        0.3f, 1f,
        infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val status = when {
        vm.engineError != null -> "Model missing"
        vm.engineReady -> "Ready"
        else -> "Getting ready"
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Display("lift", 30)
            Spacer(Modifier.weight(1f))
            Canvas(Modifier.size(9.dp)) {
                drawCircle(
                    when {
                        vm.engineError != null -> Color(0xFFD62B2B)
                        vm.engineReady -> C.Cobalt
                        else -> C.Amber.copy(alpha = pulse.value)
                    }
                )
            }
            Spacer(Modifier.width(8.dp))
            Body(status, size = 13)
        }

        Spacer(Modifier.height(18.dp))
        Display("Lift the subject.\nLose the rest.", 54, lineHeight = 54)
        Spacer(Modifier.height(16.dp))

        Canvas(
            Modifier
                .fillMaxWidth()
                .height(250.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(C.Panel)
        ) {
            val w = size.width
            val h = size.height
            val path = blobPath(w * 0.5f, h * 0.5f, minOf(w * 0.34f, h * 0.36f), morph.value)

            clipPath(path, clipOp = ClipOp.Difference) {
                val gap = 16.dp.toPx()
                var x = -h + slide.value * gap
                while (x < w + gap) {
                    drawLine(C.Line, Offset(x, h), Offset(x + h, 0f), 1.5.dp.toPx())
                    x += gap
                }
            }
            clipPath(path) {
                val k = slide.value * 28.dp.toPx()
                checker(14.dp.toPx(), ox = k, oy = k)
                val bob = sin(morph.value * 2f) * 5.dp.toPx()
                val cx = w * 0.5f
                val cy = h * 0.5f + bob
                drawCircle(C.Cobalt, h * 0.1f, Offset(cx, cy - h * 0.08f))
                drawRoundRect(
                    C.Cobalt,
                    Offset(cx - h * 0.17f, cy + h * 0.05f),
                    Size(h * 0.34f, h * 0.3f),
                    CornerRadius(h * 0.17f)
                )
            }
            drawPath(
                path, C.Ink,
                style = Stroke(
                    width = 2.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(
                        floatArrayOf(14.dp.toPx(), 10.dp.toPx()),
                        slide.value * 24.dp.toPx()
                    )
                )
            )
        }

        Spacer(Modifier.height(20.dp))

        Box(
            Modifier
                .fillMaxWidth()
                .pressable(onClick = onSingle)
                .background(C.Cobalt, RoundedCornerShape(28.dp))
                .padding(24.dp)
        ) {
            Column(Modifier.align(Alignment.CenterStart).padding(end = 40.dp)) {
                Display("One photo", 38, color = Color.White)
                Spacer(Modifier.height(4.dp))
                Body("Cut it out, then brush the edges clean.", color = Color.White.copy(alpha = 0.82f))
            }
            GlyphIcon(Glyph.Forward, Color.White, Modifier.align(Alignment.CenterEnd), 28.dp)
        }

        Spacer(Modifier.height(12.dp))

        Box(
            Modifier
                .fillMaxWidth()
                .pressable(onClick = onBulk)
                .background(C.Panel, RoundedCornerShape(16.dp))
                .border(1.5.dp, C.Ink, RoundedCornerShape(16.dp))
                .padding(20.dp)
        ) {
            Column(Modifier.align(Alignment.CenterStart).padding(end = 40.dp)) {
                Display("Many photos", 32)
                Spacer(Modifier.height(4.dp))
                Body("Pick 50, 200, more. They run in a row, then save together.")
            }
            GlyphIcon(Glyph.Forward, C.Ink, Modifier.align(Alignment.CenterEnd), 26.dp)
        }

        Spacer(Modifier.height(18.dp))
        Body("Everything runs on your phone. Nothing is uploaded.", size = 13)
        Spacer(Modifier.height(12.dp))
    }
}
