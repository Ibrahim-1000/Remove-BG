package com.liftapp.cutout.ui

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.liftapp.cutout.AppViewModel
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.sin

private val Swatches: List<Int?> = listOf(
    null,
    0xFFFFFFFF.toInt(),
    0xFF14181D.toInt(),
    0xFFE9E2D0.toInt(),
    0xFF2A3CFF.toInt(),
    0xFFFFB020.toInt(),
    0xFF2F7D5B.toInt(),
    0xFF9CC3E6.toInt()
)

private class Tile(val c: Int, val r: Int, val delay: Float, val vx: Float, val vy: Float, val rot: Float)
private class TileSet(val cols: Int, val rows: Int, val tiles: List<Tile>)

private fun buildTiles(mask: Bitmap): TileSet {
    val cols = 22
    val rows = (cols * mask.height / mask.width.toFloat()).roundToInt().coerceIn(8, 44)
    val rnd = java.util.Random(7)
    val list = ArrayList<Tile>()
    for (r in 0 until rows) {
        for (c in 0 until cols) {
            var cover = 0
            for (sy in 0..2) {
                for (sx in 0..2) {
                    val px = (((c + (sx + 0.5f) / 3f) / cols) * mask.width).toInt().coerceIn(0, mask.width - 1)
                    val py = (((r + (sy + 0.5f) / 3f) / rows) * mask.height).toInt().coerceIn(0, mask.height - 1)
                    if ((mask.getPixel(px, py) ushr 24) > 128) cover++
                }
            }
            if (cover < 9) {
                val delay = (c / cols.toFloat()) * 0.5f + rnd.nextFloat() * 0.12f
                list.add(
                    Tile(
                        c, r, delay,
                        0.25f + rnd.nextFloat() * 0.9f,
                        -(0.15f + rnd.nextFloat() * 1.1f),
                        (rnd.nextFloat() - 0.5f) * 2f
                    )
                )
            }
        }
    }
    return TileSet(cols, rows, list)
}

@Composable
fun SingleScreen(vm: AppViewModel, onBack: () -> Unit) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.startSingle(uri)
    }
    val scope = rememberCoroutineScope()
    var mode by remember { mutableIntStateOf(0) }
    var erase by remember { mutableStateOf(true) }
    var brushFrac by remember { mutableFloatStateOf(0.3f) }
    val divider = remember { Animatable(if (vm.sPhase == 2) 0.5f else 0f) }
    val shatter = remember { Animatable(1f) }
    val phase = vm.sPhase

    LaunchedEffect(phase) {
        if (phase == 1) {
            shatter.snapTo(0f)
            divider.snapTo(0f)
            mode = 0
        } else if (phase == 2 && shatter.value < 1f) {
            shatter.animateTo(1f, tween(1800, easing = LinearEasing))
            divider.animateTo(0.5f, spring(0.75f, 90f))
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar("One photo", onBack) {
            if (phase != 0) {
                Box(Modifier.pressable { pick.launch("image/*") }.padding(horizontal = 10.dp, vertical = 8.dp)) {
                    Body("New photo", color = C.Cobalt, size = 15, bold = true)
                }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp)) {
            when (phase) {
                0 -> DropFrame(
                    "Choose a photo", "JPG, PNG or WebP",
                    Modifier.fillMaxSize().padding(vertical = 8.dp)
                ) { pick.launch("image/*") }

                3 -> Column(
                    Modifier.align(Alignment.Center).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Display("That didn't work", 32)
                    Spacer(Modifier.height(8.dp))
                    Body(vm.sError, color = C.Ink, size = 15)
                    Spacer(Modifier.height(18.dp))
                    LiftButton("Try another photo", filled = true) { pick.launch("image/*") }
                }

                else -> SingleStage(
                    vm = vm,
                    mode = mode,
                    erase = erase,
                    brushFrac = brushFrac,
                    divider = divider.value,
                    shatter = shatter.value,
                    onDivider = { v -> scope.launch { divider.snapTo(v) } },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        if (phase == 1) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 22.dp)) {
                Body("Finding the edges", color = C.Ink, size = 16, bold = true)
            }
        }

        if (phase == 2) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(C.Panel, RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                    .padding(horizontal = 18.dp, vertical = 16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Tab("Compare", mode == 0) { mode = 0 }
                    Spacer(Modifier.width(22.dp))
                    Tab("Brush", mode == 1) { mode = 1 }
                    Spacer(Modifier.weight(1f))
                    if (mode == 1) {
                        Row(
                            Modifier
                                .pressable(enabled = vm.undoCount > 0) { vm.undo() }
                                .padding(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            GlyphIcon(Glyph.Undo, C.Ink, dp = 18.dp)
                            Spacer(Modifier.width(6.dp))
                            Body("Undo", color = C.Ink, size = 14, bold = true)
                        }
                    }
                }
                AnimatedVisibility(visible = mode == 1) {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Chip("Erase", erase) { erase = true }
                        Spacer(Modifier.width(8.dp))
                        Chip("Restore", !erase) { erase = false }
                        Spacer(Modifier.width(14.dp))
                        Slider01(brushFrac, { brushFrac = it }, Modifier.weight(1f))
                    }
                }
                Spacer(Modifier.height(12.dp))
                Body("Background", size = 13)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(vertical = 8.dp)
                ) {
                    Swatches.forEach { sw ->
                        Swatch(sw, vm.sBg == sw) { vm.sBg = sw }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth()) {
                    LiftButton(
                        "Save PNG", Modifier.weight(1f),
                        filled = true, glyph = Glyph.Save, enabled = !vm.saving
                    ) { vm.saveSingle() }
                    Spacer(Modifier.width(10.dp))
                    LiftButton("Another photo", Modifier.weight(1f)) { pick.launch("image/*") }
                }
            }
        }
    }
}

@Composable
private fun Swatch(color: Int?, selected: Boolean, onClick: () -> Unit) {
    Box(Modifier.padding(end = 10.dp).size(38.dp).pressable(onClick = onClick)) {
        Canvas(Modifier.fillMaxSize()) {
            val rr = size.minDimension / 2f
            val inner = rr - 5.dp.toPx()
            val c = Offset(size.width / 2f, size.height / 2f)
            if (color == null) {
                val oval = Path()
                oval.addOval(Rect(c, inner))
                clipPath(oval) { checker(8.dp.toPx()) }
            } else {
                drawCircle(Color(color), inner, c)
            }
            drawCircle(C.Line, inner, c, style = Stroke(1.dp.toPx()))
            if (selected) drawCircle(C.Cobalt, rr - 1.5.dp.toPx(), c, style = Stroke(2.5.dp.toPx()))
        }
    }
}

@Composable
private fun SingleStage(
    vm: AppViewModel,
    mode: Int,
    erase: Boolean,
    brushFrac: Float,
    divider: Float,
    shatter: Float,
    onDivider: (Float) -> Unit,
    modifier: Modifier
) {
    val orig = vm.sOriginal
    val mask = vm.sMask
    val phase = vm.sPhase
    if (orig == null) {
        Box(modifier, contentAlignment = Alignment.Center) { Body("Opening photo", size = 15) }
        return
    }
    val origImg = remember(orig) { orig.asImageBitmap() }
    val maskImg = remember(mask) { mask?.asImageBitmap() }
    val tiles = remember(mask) { if (mask != null) buildTiles(mask) else null }

    val inf = rememberInfiniteTransition(label = "stage")
    val scan = inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "scan"
    )
    var cursor by remember { mutableStateOf<Offset?>(null) }
    val radiusDp = 6f + 44f * brushFrac

    Box(modifier.clipToBounds()) {
        if (phase == 1) {
            Canvas(Modifier.fillMaxSize()) {
                val r = fitRect(size.width, size.height, orig.width, orig.height)
                val off = IntOffset(r.left.roundToInt(), r.top.roundToInt())
                val sz = IntSize(r.width.roundToInt(), r.height.roundToInt())
                drawImage(origImg, dstOffset = off, dstSize = sz, filterQuality = FilterQuality.High)
                clipRect(r.left, r.top, r.right, r.bottom) {
                    drawRect(C.Paper.copy(alpha = 0.35f))
                    val x = r.left + r.width * scan.value
                    val band = 90.dp.toPx()
                    drawRect(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, C.Cobalt.copy(alpha = 0.45f), Color.Transparent),
                            startX = x - band,
                            endX = x + band
                        ),
                        Offset(x - band, r.top),
                        Size(band * 2f, r.height)
                    )
                    drawLine(C.Cobalt, Offset(x, r.top), Offset(x, r.bottom), 3.dp.toPx())
                }
                val m = 18.dp.toPx()
                val sw = 3.dp.toPx()
                fun mark(x: Float, y: Float, dx: Float, dy: Float) {
                    drawLine(C.Ink, Offset(x, y), Offset(x + dx * m, y), sw)
                    drawLine(C.Ink, Offset(x, y), Offset(x, y + dy * m), sw)
                }
                mark(r.left, r.top, 1f, 1f)
                mark(r.right, r.top, -1f, 1f)
                mark(r.left, r.bottom, 1f, -1f)
                mark(r.right, r.bottom, -1f, -1f)
            }
        }

        if (phase == 2 && maskImg != null) {
            // backdrop
            Canvas(Modifier.fillMaxSize()) {
                val r = fitRect(size.width, size.height, orig.width, orig.height)
                clipRect(r.left, r.top, r.right, r.bottom) {
                    val bg = vm.sBg
                    if (bg == null) checker(12.dp.toPx()) else drawRect(Color(bg))
                }
            }

            // the cutout itself
            Canvas(Modifier.fillMaxSize().graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }) {
                @Suppress("UNUSED_VARIABLE")
                val rev = vm.sRev
                val r = fitRect(size.width, size.height, orig.width, orig.height)
                val off = IntOffset(r.left.roundToInt(), r.top.roundToInt())
                val sz = IntSize(r.width.roundToInt(), r.height.roundToInt())
                val edge = if (mode == 0) r.left + r.width * divider else r.left
                clipRect(left = edge) {
                    drawImage(origImg, dstOffset = off, dstSize = sz, filterQuality = FilterQuality.High)
                    drawImage(
                        maskImg, dstOffset = off, dstSize = sz,
                        blendMode = BlendMode.DstIn, filterQuality = FilterQuality.High
                    )
                }
            }

            // before / after
            if (mode == 0 && divider > 0.002f) {
                Canvas(Modifier.fillMaxSize()) {
                    val r = fitRect(size.width, size.height, orig.width, orig.height)
                    val off = IntOffset(r.left.roundToInt(), r.top.roundToInt())
                    val sz = IntSize(r.width.roundToInt(), r.height.roundToInt())
                    val x = r.left + r.width * divider
                    clipRect(r.left, r.top, x, r.bottom) {
                        drawImage(origImg, dstOffset = off, dstSize = sz, filterQuality = FilterQuality.High)
                    }
                    drawLine(Color.White, Offset(x, r.top), Offset(x, r.bottom), 3.dp.toPx())
                    val cy = (r.top + r.bottom) / 2f
                    drawCircle(C.Cobalt, 18.dp.toPx(), Offset(x, cy))
                    val a = 4.dp.toPx()
                    val b = 6.dp.toPx()
                    val chev = Path()
                    chev.moveTo(x - a, cy - b); chev.lineTo(x - a - b, cy); chev.lineTo(x - a, cy + b)
                    chev.moveTo(x + a, cy - b); chev.lineTo(x + a + b, cy); chev.lineTo(x + a, cy + b)
                    drawPath(
                        chev, Color.White,
                        style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }
            }

            // the shatter: background tiles burn off and fly away
            if (shatter < 1f && tiles != null) {
                Canvas(Modifier.fillMaxSize()) {
                    val r = fitRect(size.width, size.height, orig.width, orig.height)
                    val tw = r.width / tiles.cols
                    val th = r.height / tiles.rows
                    val sw = orig.width / tiles.cols.toFloat()
                    val sh = orig.height / tiles.rows.toFloat()
                    for (t in tiles.tiles) {
                        val local = ((shatter * 1.6f - t.delay) / 0.9f).coerceIn(0f, 1f)
                        if (local >= 1f) continue
                        val e = local * local
                        val x = r.left + t.c * tw
                        val y = r.top + t.r * th
                        val pivot = Offset(x + tw / 2f, y + th / 2f)
                        val sx0 = (t.c * sw).toInt()
                        val sy0 = (t.r * sh).toInt()
                        val sx1 = ((t.c + 1) * sw).toInt().coerceAtMost(orig.width)
                        val sy1 = ((t.r + 1) * sh).toInt().coerceAtMost(orig.height)
                        withTransform({
                            translate(t.vx * e * r.width * 0.35f, t.vy * e * r.height * 0.35f)
                            rotate(t.rot * e * 160f, pivot)
                            scale(1f - 0.7f * e, 1f - 0.7f * e, pivot)
                        }) {
                            drawImage(
                                origImg,
                                srcOffset = IntOffset(sx0, sy0),
                                srcSize = IntSize((sx1 - sx0).coerceAtLeast(1), (sy1 - sy0).coerceAtLeast(1)),
                                dstOffset = IntOffset(x.toInt(), y.toInt()),
                                dstSize = IntSize(ceil(tw).toInt() + 1, ceil(th).toInt() + 1),
                                alpha = 1f - e
                            )
                        }
                        if (local > 0.001f && local < 0.35f) {
                            val glow = sin(local / 0.35f * PI.toFloat()) * 0.55f
                            drawRect(C.Cobalt.copy(alpha = glow), Offset(x, y), Size(tw + 1f, th + 1f))
                        }
                    }
                }
            }

            // touch layer: drag the divider, or paint on the matte
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(mode, erase, radiusDp) {
                        detectTapGestures { p ->
                            val r = fitRect(size.width.toFloat(), size.height.toFloat(), orig.width, orig.height)
                            if (mode == 0) {
                                onDivider(((p.x - r.left) / r.width).coerceIn(0f, 1f))
                            } else {
                                val k = orig.width / r.width
                                vm.beginStroke()
                                vm.brush(
                                    (p.x - r.left) * k, (p.y - r.top) * k,
                                    (p.x - r.left) * k, (p.y - r.top) * k,
                                    radiusDp * density * k, erase
                                )
                            }
                        }
                    }
                    .pointerInput(mode, erase, radiusDp) {
                        var last = Offset.Zero
                        fun stroke(a: Offset, b: Offset) {
                            val r = fitRect(size.width.toFloat(), size.height.toFloat(), orig.width, orig.height)
                            val k = orig.width / r.width
                            vm.brush(
                                (a.x - r.left) * k, (a.y - r.top) * k,
                                (b.x - r.left) * k, (b.y - r.top) * k,
                                radiusDp * density * k, erase
                            )
                        }
                        fun setDivider(x: Float) {
                            val r = fitRect(size.width.toFloat(), size.height.toFloat(), orig.width, orig.height)
                            onDivider(((x - r.left) / r.width).coerceIn(0f, 1f))
                        }
                        if (mode == 0) {
                            detectDragGestures(onDragStart = { p -> setDivider(p.x) }) { change, _ ->
                                change.consume()
                                setDivider(change.position.x)
                            }
                        } else {
                            detectDragGestures(
                                onDragStart = { p ->
                                    vm.beginStroke()
                                    last = p
                                    cursor = p
                                    stroke(p, p)
                                },
                                onDragEnd = { cursor = null },
                                onDragCancel = { cursor = null }
                            ) { change, _ ->
                                change.consume()
                                stroke(last, change.position)
                                last = change.position
                                cursor = change.position
                            }
                        }
                    }
            )

            val cur = cursor
            if (mode == 1 && cur != null) {
                Canvas(Modifier.fillMaxSize()) {
                    val rad = radiusDp.dp.toPx()
                    drawCircle(Color.White, rad, cur, style = Stroke(3.dp.toPx()))
                    drawCircle(C.Ink, rad, cur, style = Stroke(1.5.dp.toPx()))
                }
            }
        }
    }
}
