package com.liftapp.cutout

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.OutputStream
import kotlin.math.roundToInt

object Imaging {

    fun decode(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        val orient = try {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
            } ?: 1
        } catch (e: Exception) {
            1
        }
        val m = Matrix()
        when (orient) {
            2 -> m.postScale(-1f, 1f)
            3 -> m.postRotate(180f)
            4 -> m.postScale(1f, -1f)
            5 -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            6 -> m.postRotate(90f)
            7 -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
            8 -> m.postRotate(-90f)
        }
        val big = maxOf(raw.width, raw.height)
        if (big > maxSide) {
            val f = maxSide / big.toFloat()
            m.postScale(f, f)
        }
        if (m.isIdentity) return raw
        val out = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
        if (out !== raw) raw.recycle()
        return out
    }

    fun thumb(b: Bitmap, max: Int): Bitmap {
        val s = max / maxOf(b.width, b.height).toFloat()
        if (s >= 1f) return b.copy(Bitmap.Config.ARGB_8888, false)
        val w = (b.width * s).roundToInt().coerceAtLeast(1)
        val h = (b.height * s).roundToInt().coerceAtLeast(1)
        val t = Bitmap.createScaledBitmap(b, w, h, true)
        return if (t === b) b.copy(Bitmap.Config.ARGB_8888, false) else t
    }

    /** Original pixels with the matte applied as alpha. */
    fun cutout(original: Bitmap, mask: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(original.width, original.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(original, 0f, 0f, null)
        val p = Paint()
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        c.drawBitmap(mask, 0f, 0f, p)
        return out
    }

    fun onColor(cut: Bitmap, color: Int): Bitmap {
        val out = Bitmap.createBitmap(cut.width, cut.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(color)
        c.drawBitmap(cut, 0f, 0f, null)
        return out
    }

    fun saveMedia(ctx: Context, name: String, mime: String, isImage: Boolean, write: (OutputStream) -> Unit): Uri? {
        val resolver = ctx.contentResolver
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    if (isImage) "Pictures/Lift" else "Download/Lift"
                )
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val collection = if (isImage) {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            } else {
                MediaStore.Downloads.EXTERNAL_CONTENT_URI
            }
            val uri = resolver.insert(collection, cv) ?: return null
            return try {
                val stream = resolver.openOutputStream(uri) ?: throw IllegalStateException("no stream")
                stream.use { write(it) }
                val done = ContentValues()
                done.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(uri, done, null, null)
                uri
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                null
            }
        } else {
            return try {
                val base = Environment.getExternalStoragePublicDirectory(
                    if (isImage) Environment.DIRECTORY_PICTURES else Environment.DIRECTORY_DOWNLOADS
                )
                val dir = File(base, "Lift")
                dir.mkdirs()
                val f = File(dir, name)
                f.outputStream().use { write(it) }
                MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), arrayOf(mime), null)
                Uri.fromFile(f)
            } catch (e: Exception) {
                null
            }
        }
    }
}
