package com.liftapp.cutout

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color as AColor
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.net.Uri
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import java.io.BufferedOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class BulkItem(val id: Int, val uri: Uri) {
    var state by mutableIntStateOf(0) // 0 waiting, 1 working, 2 done, 3 failed
    var thumb by mutableStateOf<Bitmap?>(null)
    var cutThumb by mutableStateOf<Bitmap?>(null)
    var doneAt by mutableStateOf(0L)
    @Volatile var file: File? = null
    @Volatile var cancelled = false
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val engine = Engine(app)
    var engineReady by mutableStateOf(false)
    var engineError by mutableStateOf<String?>(null)
    var toast by mutableStateOf<String?>(null)
    var saving by mutableStateOf(false)

    // single photo
    var sOriginal by mutableStateOf<Bitmap?>(null)
    var sMask by mutableStateOf<Bitmap?>(null)
    var sPhase by mutableIntStateOf(0) // 0 empty, 1 working, 2 done, 3 failed
    var sRev by mutableIntStateOf(0)
    var sBg by mutableStateOf<Int?>(null)
    var sError by mutableStateOf("")
    var undoCount by mutableIntStateOf(0)
    private val undoStack = ArrayList<Bitmap>()

    // batch
    val bulk = mutableStateListOf<BulkItem>()
    private var nextId = 1
    private val queue = Channel<BulkItem>(Channel.UNLIMITED)
    private val resultsDir = File(app.cacheDir, "results").apply { mkdirs() }

    private val clearPaint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }
    private val fillPaint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = AColor.BLACK
    }

    init {
        viewModelScope.launch(Dispatchers.Default) {
            try {
                engine.prepare()
                engineReady = true
            } catch (t: Throwable) {
                engineError = t.message ?: t.javaClass.simpleName
            }
        }
        viewModelScope.launch(Dispatchers.Default) {
            for (item in queue) processBulk(item)
        }
    }

    // ---- single ----

    fun startSingle(uri: Uri) {
        sPhase = 1
        sOriginal = null
        sMask = null
        undoStack.clear()
        undoCount = 0
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val bmp = Imaging.decode(getApplication(), uri, 2560)
                    ?: throw IllegalStateException("That photo could not be opened.")
                sOriginal = bmp
                val m = engine.matte(bmp)
                sMask = m
                sPhase = 2
            } catch (t: Throwable) {
                sError = if (t is OutOfMemoryError) {
                    "Not enough memory for this photo. Try a smaller one."
                } else {
                    t.message ?: "Something went wrong."
                }
                sPhase = 3
            }
        }
    }

    fun beginStroke() {
        val m = sMask ?: return
        undoStack.add(m.copy(Bitmap.Config.ARGB_8888, true))
        if (undoStack.size > 5) undoStack.removeAt(0)
        undoCount = undoStack.size
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        sMask = undoStack.removeAt(undoStack.lastIndex)
        undoCount = undoStack.size
        sRev++
    }

    fun brush(x1: Float, y1: Float, x2: Float, y2: Float, radius: Float, erase: Boolean) {
        val m = sMask ?: return
        val p = if (erase) clearPaint else fillPaint
        val r = maxOf(radius, 1f)
        p.strokeWidth = r * 2f
        p.maskFilter = BlurMaskFilter(maxOf(1f, r * 0.3f), BlurMaskFilter.Blur.NORMAL)
        val ex = if (x1 == x2 && y1 == y2) x2 + 0.01f else x2
        Canvas(m).drawLine(x1, y1, ex, y2, p)
        sRev++
    }

    fun saveSingle() {
        val o = sOriginal ?: return
        val m = sMask ?: return
        val bg = sBg
        if (saving) return
        saving = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val cut = Imaging.cutout(o, m)
                val out = if (bg == null) cut else Imaging.onColor(cut, bg)
                val uri = Imaging.saveMedia(
                    getApplication(), "lift_${System.currentTimeMillis()}.png", "image/png", true
                ) { s -> out.compress(Bitmap.CompressFormat.PNG, 100, s) }
                toast = if (uri != null) "Saved to Pictures/Lift" else "Could not save the image"
            } catch (t: Throwable) {
                toast = "Could not save the image"
            }
            saving = false
        }
    }

    // ---- batch ----

    fun addBulk(uris: List<Uri>) {
        for (u in uris) {
            val item = BulkItem(nextId++, u)
            bulk.add(item)
            queue.trySend(item)
        }
    }

    private fun processBulk(item: BulkItem) {
        if (item.cancelled) return
        item.state = 1
        try {
            val bmp = Imaging.decode(getApplication(), item.uri, 2048)
                ?: throw IllegalStateException("open")
            item.thumb = Imaging.thumb(bmp, 256)
            val mask = engine.matte(bmp)
            val cut = Imaging.cutout(bmp, mask)
            val f = File(resultsDir, "lift_${item.id}.png")
            f.outputStream().buffered().use { cut.compress(Bitmap.CompressFormat.PNG, 100, it) }
            item.cutThumb = Imaging.thumb(cut, 256)
            item.file = f
            bmp.recycle()
            mask.recycle()
            cut.recycle()
            item.doneAt = SystemClock.elapsedRealtime()
            item.state = 2
        } catch (t: Throwable) {
            item.state = 3
        }
    }

    fun clearBulk() {
        for (i in bulk) {
            i.cancelled = true
            i.file?.delete()
        }
        bulk.clear()
    }

    fun saveAllBulk() {
        if (saving) return
        val list = bulk.filter { it.state == 2 && it.file != null }
        if (list.isEmpty()) return
        saving = true
        val stamp = System.currentTimeMillis()
        viewModelScope.launch(Dispatchers.IO) {
            var ok = 0
            list.forEachIndexed { idx, item ->
                val f = item.file ?: return@forEachIndexed
                val u = Imaging.saveMedia(getApplication(), "lift_${stamp}_${idx + 1}.png", "image/png", true) { out ->
                    f.inputStream().use { src -> src.copyTo(out) }
                }
                if (u != null) ok++
            }
            toast = "Saved $ok of ${list.size} to Pictures/Lift"
            saving = false
        }
    }

    fun zipBulk() {
        if (saving) return
        val list = bulk.filter { it.state == 2 && it.file != null }
        if (list.isEmpty()) return
        saving = true
        viewModelScope.launch(Dispatchers.IO) {
            val u = Imaging.saveMedia(
                getApplication(), "lift_${System.currentTimeMillis()}.zip", "application/zip", false
            ) { out ->
                ZipOutputStream(BufferedOutputStream(out)).use { z ->
                    list.forEachIndexed { idx, item ->
                        val f = item.file
                        if (f != null) {
                            z.putNextEntry(ZipEntry("lift_${idx + 1}.png"))
                            f.inputStream().use { src -> src.copyTo(z) }
                            z.closeEntry()
                        }
                    }
                }
            }
            toast = if (u != null) "Zip saved to Downloads/Lift" else "Could not save the zip"
            saving = false
        }
    }
}
