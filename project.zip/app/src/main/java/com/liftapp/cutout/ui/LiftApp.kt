package com.liftapp.cutout.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.liftapp.cutout.AppViewModel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private fun Modifier.blockTouches(): Modifier = pointerInput(Unit) {
    awaitPointerEventScope {
        while (true) {
            val e = awaitPointerEvent()
            e.changes.forEach { it.consume() }
        }
    }
}

@Composable
fun LiftApp(vm: AppViewModel = viewModel()) {
    var screen by remember { mutableIntStateOf(0) }
    var splashDone by remember { mutableStateOf(false) }
    var wiping by remember { mutableStateOf(false) }
    val wipe = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    fun go(target: Int) {
        if (wiping) return
        scope.launch {
            wiping = true
            wipe.snapTo(0f)
            wipe.animateTo(1f, tween(420, easing = CubicBezierEasing(0.6f, 0f, 0.3f, 1f)))
            screen = target
            wipe.animateTo(2f, tween(420, easing = CubicBezierEasing(0.7f, 0f, 0.3f, 1f)))
            wipe.snapTo(0f)
            wiping = false
        }
    }

    LaunchedEffect(vm.toast) {
        if (vm.toast != null) {
            delay(2600)
            vm.toast = null
        }
    }

    BackHandler(enabled = screen != 0 && !wiping) { go(0) }

    Box(Modifier.fillMaxSize().background(C.Paper)) {
        when (screen) {
            0 -> HomeScreen(vm, onSingle = { go(1) }, onBulk = { go(2) })
            1 -> SingleScreen(vm, onBack = { go(0) })
            else -> BulkScreen(vm, onBack = { go(0) })
        }
        ToastBar(vm.toast, Modifier.align(Alignment.BottomCenter))
        if (wipe.value > 0f) WipeOverlay(wipe.value)
        if (wiping) Box(Modifier.fillMaxSize().blockTouches())
        if (!splashDone) Splash { splashDone = true }
    }
}

@Composable
private fun WipeOverlay(v: Float) {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val slant = h * 0.22f
        val travel = w + slant
        val strip = 24.dp.toPx()
        val body = Path()
        val edge = Path()
        if (v <= 1f) {
            val f = v * travel
            body.moveTo(0f, 0f); body.lineTo(f, 0f); body.lineTo(f - slant, h); body.lineTo(0f, h); body.close()
            edge.moveTo(f - strip, 0f); edge.lineTo(f, 0f); edge.lineTo(f - slant, h); edge.lineTo(f - slant - strip, h); edge.close()
        } else {
            val r = (v - 1f) * travel
            body.moveTo(r, 0f); body.lineTo(travel + 2f, 0f); body.lineTo(travel + 2f, h); body.lineTo(r - slant, h); body.close()
            edge.moveTo(r, 0f); edge.lineTo(r + strip, 0f); edge.lineTo(r + strip - slant, h); edge.lineTo(r - slant, h); edge.close()
        }
        drawPath(body, C.Cobalt)
        drawPath(edge, C.Paper)
    }
}

@Composable
private fun Splash(onFinished: () -> Unit) {
    val letters = listOf("l", "i", "f", "t", ".")
    val rise = remember { letters.map { Animatable(0f) } }
    val line = remember { Animatable(0f) }
    val sub = remember { Animatable(0f) }
    val split = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        coroutineScope {
            rise.forEachIndexed { i, a ->
                launch {
                    delay(200L + i * 90L)
                    a.animateTo(1f, spring(0.62f, 260f))
                }
            }
            launch {
                delay(300)
                line.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
            }
            launch {
                delay(900)
                sub.animateTo(1f, tween(500))
            }
        }
        delay(300)
        split.animateTo(1f, tween(800, easing = CubicBezierEasing(0.75f, 0f, 0.2f, 1f)))
        onFinished()
    }

    Box(Modifier.fillMaxSize().blockTouches()) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val yl = h * 0.60f
            val yr = h * 0.40f
            val s = split.value
            val c = line.value
            val up = Path()
            up.moveTo(0f, 0f); up.lineTo(w, 0f); up.lineTo(w, yr); up.lineTo(0f, yl); up.close()
            val dn = Path()
            dn.moveTo(0f, yl); dn.lineTo(w, yr); dn.lineTo(w, h); dn.lineTo(0f, h); dn.close()
            val sw = 3.dp.toPx()
            translate(top = -s * h * 0.7f) {
                drawPath(up, C.Paper)
                drawLine(C.Cobalt, Offset(0f, yl), Offset(w * c, yl + (yr - yl) * c), sw)
            }
            translate(top = s * h * 0.7f) {
                drawPath(dn, C.Paper)
                drawLine(C.Cobalt, Offset(0f, yl), Offset(w * c, yl + (yr - yl) * c), sw)
            }
        }
        val fade = (1f - split.value * 4f).coerceIn(0f, 1f)
        Column(
            Modifier.align(Alignment.Center).graphicsLayer { alpha = fade },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row {
                letters.forEachIndexed { i, ch ->
                    Box(Modifier.clipToBounds()) {
                        Display(
                            ch, 128,
                            Modifier.graphicsLayer { translationY = (1f - rise[i].value) * 190.dp.toPx() },
                            color = if (ch == ".") C.Cobalt else C.Ink,
                            spacing = -4f
                        )
                    }
                }
            }
            Body("Background remover", Modifier.graphicsLayer { alpha = sub.value }, size = 15)
        }
    }
}

@Composable
private fun ToastBar(text: String?, modifier: Modifier) {
    var last by remember { mutableStateOf("") }
    if (text != null && text != last) last = text
    AnimatedVisibility(
        visible = text != null,
        modifier = modifier.padding(bottom = 28.dp),
        enter = slideInVertically(tween(300)) { it * 2 } + fadeIn(tween(200)),
        exit = slideOutVertically(tween(260)) { it * 2 } + fadeOut(tween(200))
    ) {
        Box(
            Modifier
                .background(C.Ink, RoundedCornerShape(14.dp))
                .padding(horizontal = 20.dp, vertical = 13.dp)
        ) {
            Body(last, color = Color.White, size = 14, bold = true)
        }
    }
}
