package com.liftapp.cutout

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Runs the segmentation model on the phone. The model file is added to
 * assets/model.onnx while the app is built (see the workflow).
 */
class Engine(private val ctx: Context) {
    private var env: OrtEnvironment? = null
    private var session: OrtSession? = null
    private val lock = Any()
    private val side = 1024

    fun prepare() {
        synchronized(lock) {
            if (session != null) return
            val file = File(ctx.filesDir, "engine_v1.onnx")
            if (!file.exists() || file.length() < 1_000_000L) {
                val tmp = File(ctx.filesDir, "engine_v1.part")
                ctx.assets.open("model.onnx").use { input ->
                    tmp.outputStream().use { out -> input.copyTo(out, 1 shl 16) }
                }
                if (!tmp.renameTo(file)) throw IllegalStateException("Could not unpack the model")
            }
            val e = OrtEnvironment.getEnvironment()
            val o = OrtSession.SessionOptions()
            o.setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 4))
            o.setMemoryPatternOptimization(false)
            o.setCPUArenaAllocator(false)
            session = e.createSession(file.absolutePath, o)
            env = e
        }
    }

    /** Returns a mutable bitmap, same size as [src], whose alpha channel is the cutout matte. */
    fun matte(src: Bitmap): Bitmap {
        prepare()
        val s = session!!
        val e = env!!
        val n = side
        val plane = n * n

        val small = Bitmap.createScaledBitmap(src, n, n, true)
        val px = IntArray(plane)
        small.getPixels(px, 0, n, 0, 0, n, n)
        if (small !== src) small.recycle()

        val data = FloatArray(plane * 3)
        for (i in 0 until plane) {
            val p = px[i]
            data[i] = ((p shr 16) and 255) / 255f - 0.485f
            data[plane + i] = ((p shr 8) and 255) / 255f - 0.456f
            data[2 * plane + i] = (p and 255) / 255f - 0.406f
        }
        val buf = ByteBuffer.allocateDirect(plane * 3 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        buf.put(data)
        buf.rewind()

        val out = FloatArray(plane)
        val tensor = OnnxTensor.createTensor(e, buf, longArrayOf(1, 3, n.toLong(), n.toLong()))
        try {
            val inputName = s.inputNames.iterator().next()
            s.run(mapOf(inputName to tensor)).use { res ->
                val t = res.get(0) as OnnxTensor
                val fb = t.floatBuffer
                fb.rewind()
                fb.get(out, 0, plane)
            }
        } finally {
            tensor.close()
        }

        var mn = Float.MAX_VALUE
        var mx = -Float.MAX_VALUE
        for (v in out) {
            if (v < mn) mn = v
            if (v > mx) mx = v
        }
        val range = maxOf(mx - mn, 1e-6f)
        val alpha = IntArray(plane)
        for (i in 0 until plane) {
            val m = (out[i] - mn) / range
            val t = ((m - 0.05f) / 0.9f).coerceIn(0f, 1f)
            val soft = t * t * (3f - 2f * t)
            alpha[i] = ((soft * 255f + 0.5f).toInt().coerceIn(0, 255)) shl 24
        }
        val mb = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        mb.setPixels(alpha, 0, n, 0, 0, n, n)

        val up = Bitmap.createScaledBitmap(mb, src.width, src.height, true)
        if (up !== mb) mb.recycle()
        return if (up.isMutable) up else up.copy(Bitmap.Config.ARGB_8888, true)
    }
}
