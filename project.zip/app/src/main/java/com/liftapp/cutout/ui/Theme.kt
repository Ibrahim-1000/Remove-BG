package com.liftapp.cutout.ui

import android.graphics.Typeface
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.IntrinsicSize

object C {
    val Paper = Color(0xFFE5E8E7)
    val Panel = Color(0xFFF5F6F5)
    val Ink = Color(0xFF14181D)
    val Dim = Color(0xFF5C666F)
    val Line = Color(0xFFC5CBCD)
    val Cobalt = Color(0xFF2A3CFF)
    val Amber = Color(0xFFFFB020)
    val ChkA = Color(0xFFF2F4F3)
    val ChkB = Color(0xFFD7DCDD)
}

val DisplayFont: FontFamily = FontFamily(Typeface.create("sans-serif-condensed", Typeface.BOLD))

@Composable
fun Display(
    text: String,
    size: Int,
    modifier: Modifier = Modifier,
    color: Color = C.Ink,
    lineHeight: Int = 0,
    spacing: Float = -1f
) {
    BasicText(
        text = text,
        modifier = modifier,
        style = TextStyle(
            color = color,
            fontFamily = DisplayFont,
            fontSize = size.sp,
            letterSpacing = spacing.sp,
            lineHeight = if (lineHeight > 0) lineHeight.sp else TextUnit.Unspecified
        )
    )
}

@Composable
fun Body(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = C.Dim,
    size: Int = 14,
    bold: Boolean = false
) {
    BasicText(
        text = text,
        modifier = modifier,
        style = TextStyle(
            color = color,
            fontFamily = FontFamily.SansSerif,
            fontSize = size.sp,
            fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal,
            lineHeight = (size * 1.4f).sp
        )
    )
}

enum class Glyph { Back, Forward, Check, Plus, Save, Close, Undo }

@Composable
fun GlyphIcon(g: Glyph, color: Color, modifier: Modifier = Modifier, dp: Dp = 22.dp) {
    Canvas(modifier.size(dp)) {
        val s = this.size.minDimension
        val st = Stroke(width = s * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        val p = Path()
        when (g) {
            Glyph.Back -> {
                p.moveTo(s * 0.64f, s * 0.2f); p.lineTo(s * 0.3f, s * 0.5f); p.lineTo(s * 0.64f, s * 0.8f)
            }
            Glyph.Forward -> {
                p.moveTo(s * 0.36f, s * 0.2f); p.lineTo(s * 0.7f, s * 0.5f); p.lineTo(s * 0.36f, s * 0.8f)
            }
            Glyph.Check -> {
                p.moveTo(s * 0.2f, s * 0.54f); p.lineTo(s * 0.42f, s * 0.74f); p.lineTo(s * 0.8f, s * 0.28f)
            }
            Glyph.Plus -> {
                p.moveTo(s * 0.5f, s * 0.18f); p.lineTo(s * 0.5f, s * 0.82f)
                p.moveTo(s * 0.18f, s * 0.5f); p.lineTo(s * 0.82f, s * 0.5f)
            }
            Glyph.Save -> {
                p.moveTo(s * 0.5f, s * 0.14f); p.lineTo(s * 0.5f, s * 0.64f)
                p.moveTo(s * 0.3f, s * 0.46f); p.lineTo(s * 0.5f, s * 0.66f); p.lineTo(s * 0.7f, s * 0.46f)
                p.moveTo(s * 0.2f, s * 0.84f); p.lineTo(s * 0.8f, s * 0.84f)
            }
            Glyph.Close -> {
                p.moveTo(s * 0.24f, s * 0.24f); p.lineTo(s * 0.76f, s * 0.76f)
                p.moveTo(s * 0.76f, s * 0.24f); p.lineTo(s * 0.24f, s * 0.76f)
            }
            Glyph.Undo -> {
                p.moveTo(s * 0.36f, s * 0.24f); p.lineTo(s * 0.2f, s * 0.42f); p.lineTo(s * 0.4f, s * 0.58f)
                p.moveTo(s * 0.22f, s * 0.42f); p.lineTo(s * 0.62f, s * 0.42f)
                p.cubicTo(s * 0.86f, s * 0.42f, s * 0.86f, s * 0.8f, s * 0.6f, s * 0.8f)
                p.lineTo(s * 0.4f, s * 0.8f)
            }
        }
        drawPath(p, color, style = st)
    }
}

fun Modifier.pressable(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        targetValue = if (pressed) 0.965f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 520f),
        label = "press"
    )
    this
        .graphicsLayer {
            scaleX = sc
            scaleY = sc
            alpha = if (enabled) 1f else 0.4f
        }
        .clickable(interactionSource = src, indication = null, enabled = enabled) { onClick() }
}

fun fitRect(cw: Float, ch: Float, iw: Int, ih: Int): Rect {
    val s = minOf(cw / iw, ch / ih)
    val w = iw * s
    val h = ih * s
    return Rect((cw - w) / 2f, (ch - h) / 2f, (cw + w) / 2f, (ch + h) / 2f)
}

fun DrawScope.checker(
    cell: Float,
    a: Color = C.ChkA,
    b: Color = C.ChkB,
    ox: Float = 0f,
    oy: Float = 0f
) {
    clipRect(0f, 0f, size.width, size.height) {
        drawRect(a)
        val sx = ox % (cell * 2f)
        val sy = oy % (cell * 2f)
        val cols = (size.width / cell).toInt() + 3
        val rows = (size.height / cell).toInt() + 3
        for (r in -2 until rows) {
            for (c in -2 until cols) {
                if (((r + c) and 1) == 0) {
                    drawRect(b, Offset(c * cell + sx, r * cell + sy), Size(cell, cell))
                }
            }
        }
    }
}

@Composable
fun LiftButton(
    text: String,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    glyph: Glyph? = null,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val fg = if (filled) Color.White else C.Ink
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier
            .pressable(enabled = enabled, onClick = onClick)
            .background(if (filled) C.Cobalt else Color.Transparent, shape)
            .border(1.5.dp, if (filled) C.Cobalt else C.Ink, shape)
            .padding(horizontal = 14.dp, vertical = 13.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (glyph != null) {
            GlyphIcon(glyph, fg, dp = 18.dp)
            Spacer(Modifier.width(8.dp))
        }
        Body(text, color = fg, size = 15, bold = true)
    }
}

@Composable
fun TopBar(title: String, onBack: () -> Unit, right: @Composable () -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(60.dp)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).pressable(onClick = onBack), contentAlignment = Alignment.Center) {
            GlyphIcon(Glyph.Back, C.Ink)
        }
        Display(title, 32, Modifier.padding(start = 4.dp))
        Spacer(Modifier.weight(1f))
        right()
        Spacer(Modifier.width(8.dp))
    }
}

@Composable
fun Tab(text: String, selected: Boolean, onClick: () -> Unit) {
    val frac by animateFloatAsState(if (selected) 1f else 0f, tween(260), label = "tab")
    Column(Modifier.width(IntrinsicSize.Max).pressable(onClick = onClick)) {
        Body(text, color = if (selected) C.Ink else C.Dim, size = 16, bold = true)
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .fillMaxWidth(frac)
                .height(3.dp)
                .background(C.Cobalt)
        )
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .pressable(onClick = onClick)
            .background(if (selected) C.Ink else Color.Transparent, shape)
            .border(1.5.dp, C.Ink, shape)
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Body(text, color = if (selected) Color.White else C.Ink, size = 13, bold = true)
    }
}

@Composable
fun Slider01(value: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val cb by rememberUpdatedState(onChange)
    Box(
        modifier
            .height(34.dp)
            .pointerInput(Unit) {
                detectTapGestures { cb((it.x / size.width).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectDragGestures { change, _ ->
                    change.consume()
                    cb((change.position.x / size.width).coerceIn(0f, 1f))
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cy = size.height / 2f
            val pad = 10.dp.toPx()
            val x = pad + (size.width - 2 * pad) * value
            drawLine(C.Line, Offset(pad, cy), Offset(size.width - pad, cy), 3.dp.toPx(), StrokeCap.Round)
            drawLine(C.Cobalt, Offset(pad, cy), Offset(x, cy), 3.dp.toPx(), StrokeCap.Round)
            drawCircle(C.Ink, 9.dp.toPx(), Offset(x, cy))
        }
    }
}

@Composable
fun Odometer(value: Int, digits: Int, size: Int, color: Color = C.Ink) {
    val s = value.toString().padStart(digits, '0')
    Row {
        s.forEachIndexed { idx, ch ->
            AnimatedContent(
                targetState = ch,
                modifier = Modifier.clipToBounds(),
                transitionSpec = {
                    (slideInVertically(tween(420)) { it } + fadeIn(tween(420))) togetherWith
                        (slideOutVertically(tween(420)) { -it } + fadeOut(tween(420)))
                },
                label = "odo$idx"
            ) { c ->
                Display(c.toString(), size, color = color, spacing = -2f)
            }
        }
    }
}

@Composable
fun DropFrame(title: String, hint: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "drop")
    val phase = inf.animateFloat(
        0f, 24f,
        infiniteRepeatable(tween(1100, easing = LinearEasing)),
        label = "phase"
    )
    val breathe = inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe"
    )
    Box(modifier.pressable(onClick = onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val inset = 4.dp.toPx() + breathe.value * 6.dp.toPx()
            drawRoundRect(
                color = C.Ink,
                topLeft = Offset(inset, inset),
                size = Size(size.width - 2 * inset, size.height - 2 * inset),
                cornerRadius = CornerRadius(22.dp.toPx()),
                style = Stroke(
                    width = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 14f), phase.value * 2f)
                )
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(64.dp).background(C.Cobalt, RoundedCornerShape(50)),
                contentAlignment = Alignment.Center
            ) { GlyphIcon(Glyph.Plus, Color.White, dp = 28.dp) }
            Spacer(Modifier.height(16.dp))
            Display(title, 34)
            Spacer(Modifier.height(4.dp))
            Body(hint, size = 14)
        }
    }
}
