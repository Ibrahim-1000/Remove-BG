package com.liftapp.cutout.ui

import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.liftapp.cutout.AppViewModel
import com.liftapp.cutout.BulkItem
import kotlin.math.exp
import kotlin.math.roundToInt

@Composable
fun BulkScreen(vm: AppViewModel, onBack: () -> Unit) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) vm.addBulk(uris)
    }
    val items = vm.bulk
    val total = items.size
    val done = items.count { it.state == 2 }
    val failed = items.count { it.state == 3 }
    val busy = items.any { it.state == 0 || it.state == 1 }

    val inf = rememberInfiniteTransition(label = "bulk")
    val scan = inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1100, easing = LinearEasing)),
        label = "scan"
    )
    val pulse = inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )

    Column(Modifier.fillMaxSize()) {
        TopBar("Many photos", onBack) {
            if (total > 0) {
                Box(Modifier.pressable { vm.clearBulk() }.padding(horizontal = 10.dp, vertical = 8.dp)) {
                    Body("Clear", color = C.Cobalt, size = 15, bold = true)
                }
            }
        }

        if (total == 0) {
            DropFrame(
                "Pick your photos",
                "No limit. 50, 200, as many as you have.",
                Modifier.weight(1f).fillMaxWidth().padding(14.dp)
            ) { pick.launch("image/*") }
        } else {
            Column(Modifier.padding(horizontal = 22.dp)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Odometer(done, maxOf(2, total.toString().length), 72)
                    Spacer(Modifier.width(10.dp))
                    val label = if (failed > 0) "of $total done, $failed failed" else "of $total done"
                    Body(label, Modifier.padding(bottom = 14.dp), size = 15)
                }
                Spacer(Modifier.height(6.dp))
                Ruler(total, done, busy, pulse)
            }
            Spacer(Modifier.height(10.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)
            ) {
                itemsIndexed(items, key = { _, item -> item.id }) { i, item ->
                    GridTile(item, i, scan)
                }
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(C.Panel, RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                    .padding(horizontal = 16.dp, vertical = 16.dp)
            ) {
                LiftButton("Add more", Modifier.weight(1f), glyph = Glyph.Plus) { pick.launch("image/*") }
                Spacer(Modifier.width(8.dp))
                LiftButton(
                    "Save all", Modifier.weight(1f),
                    filled = true, enabled = done > 0 && !vm.saving
                ) { vm.saveAllBulk() }
                Spacer(Modifier.width(8.dp))
                LiftButton("Zip", Modifier.weight(0.7f), enabled = done > 0 && !vm.saving) { vm.zipBulk() }
            }
        }
    }
}

@Composable
private fun Ruler(total: Int, done: Int, busy: Boolean, pulse: State<Float>) {
    val n = if (total == 0) 40 else minOf(total, 90).coerceAtLeast(12)
    val target = if (total == 0) 0f else done.toFloat() / total * n
    val head by animateFloatAsState(
        targetValue = target,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 90f),
        label = "head"
    )
    Canvas(Modifier.fillMaxWidth().height(48.dp)) {
        val step = size.width / n
        val sw = step * 0.5f
        for (i in 0 until n) {
            val d = i + 0.5f - head
            val bump = exp(-(d * d) / 7f)
            val amp = if (busy) 0.5f + 0.5f * pulse.value else 0.5f
            val hh = size.height * (0.28f + 0.62f * bump * amp)
            val x = step * (i + 0.5f)
            val isDone = i + 1 <= head + 0.05f
            drawLine(
                if (isDone) C.Cobalt else C.Line,
                Offset(x, size.height), Offset(x, size.height - hh),
                sw, StrokeCap.Butt
            )
        }
    }
}

private fun DrawScope.drawCover(img: ImageBitmap) {
    val s = maxOf(size.width / img.width, size.height / img.height)
    val sw = minOf(img.width, (size.width / s).roundToInt()).coerceAtLeast(1)
    val sh = minOf(img.height, (size.height / s).roundToInt()).coerceAtLeast(1)
    drawImage(
        img,
        srcOffset = IntOffset((img.width - sw) / 2, (img.height - sh) / 2),
        srcSize = IntSize(sw, sh),
        dstOffset = IntOffset.Zero,
        dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt())
    )
}

@Composable
private fun GridTile(item: BulkItem, index: Int, scan: State<Float>) {
    val state = item.state
    val thumb = item.thumb
    val cut = item.cutThumb
    val reveal = remember(item.id) {
        Animatable(
            if (state == 2 && SystemClock.elapsedRealtime() - item.doneAt > 2500L) 1f else 0f
        )
    }
    LaunchedEffect(state) {
        if (state == 2) reveal.animateTo(1f, tween(1000, easing = FastOutSlowInEasing))
    }
    val tImg = remember(thumb) { thumb?.asImageBitmap() }
    val cImg = remember(cut) { cut?.asImageBitmap() }

    Box(
        Modifier
            .padding(3.dp)
            .aspectRatio(1f)
            .clip(RoundedCornerShape(12.dp))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawRect(C.Panel)
            val rv = reveal.value
            when {
                state == 3 -> {
                    val c = Offset(w / 2f, h / 2f)
                    val a = 10.dp.toPx()
                    drawLine(C.Dim, Offset(c.x - a, c.y - a), Offset(c.x + a, c.y + a), 3.dp.toPx(), StrokeCap.Round)
                    drawLine(C.Dim, Offset(c.x + a, c.y - a), Offset(c.x - a, c.y + a), 3.dp.toPx(), StrokeCap.Round)
                }
                state == 2 && tImg != null && cImg != null -> {
                    if (rv >= 1f) {
                        checker(10.dp.toPx())
                        drawCover(cImg)
                    } else {
                        val slant = h * 0.3f
                        val x = rv * (w + slant)
                        val left = Path()
                        left.moveTo(0f, 0f); left.lineTo(x, 0f); left.lineTo(x - slant, h); left.lineTo(0f, h); left.close()
                        val right = Path()
                        right.moveTo(x, 0f); right.lineTo(w, 0f); right.lineTo(w, h); right.lineTo(x - slant, h); right.close()
                        clipPath(right) { drawCover(tImg) }
                        clipPath(left) {
                            checker(10.dp.toPx())
                            drawCover(cImg)
                        }
                        drawLine(C.Cobalt, Offset(x, 0f), Offset(x - slant, h), 3.dp.toPx())
                    }
                }
                tImg != null -> {
                    drawCover(tImg)
                    drawRect(C.Paper.copy(alpha = 0.45f))
                    if (state == 1) {
                        val y = scan.value * h
                        val band = 40.dp.toPx()
                        drawRect(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, C.Cobalt.copy(alpha = 0.5f)),
                                startY = y - band, endY = y
                            ),
                            Offset(0f, y - band), androidx.compose.ui.geometry.Size(w, band)
                        )
                        drawLine(C.Cobalt, Offset(0f, y), Offset(w, y), 3.dp.toPx())
                    }
                }
                state == 1 -> drawCircle(C.Amber.copy(alpha = 0.3f + 0.6f * scan.value), 9.dp.toPx(), Offset(w / 2f, h / 2f))
                else -> drawCircle(C.Line, 5.dp.toPx(), Offset(w / 2f, h / 2f))
            }
        }
        Box(
            Modifier
                .align(Alignment.TopStart)
                .padding(6.dp)
                .background(C.Ink.copy(alpha = 0.65f), RoundedCornerShape(6.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Body("${index + 1}", color = Color.White, size = 11, bold = true)
        }
        if (state == 2) {
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(6.dp)
                    .size(22.dp)
                    .graphicsLayer {
                        scaleX = reveal.value
                        scaleY = reveal.value
                    }
                    .background(C.Cobalt, RoundedCornerShape(50)),
                contentAlignment = Alignment.Center
            ) {
                GlyphIcon(Glyph.Check, Color.White, dp = 13.dp)
            }
        }
    }
}
